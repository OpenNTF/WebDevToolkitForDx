wcmHelper = require('./wcmHelper');
wcmRequests = require('./lib/wcmOperations');

// wcmHelper.init('gsagercf05trans.rtp.raleigh.ibm.com', 10039, '/wps/mycontenthandler', 'wpsadmin', 'wpsadmin','C:/awcm1');
// wcmHelper.init('jb-cf06-ctc.rtp.raleigh.ibm.com', 10039, '/wps/mycontenthandler', 'wpsadmin', 'wpsadmin', 'd:/wcm_design');
// wcmHelper.init('gsagerwcmdesign.rtp.raleigh.ibm.com', 10039, '/wps/mycontenthandler/Gws', 'wpsadmin', 'wpsadmin','C:/awcm1');
// wcmHelper.init('jb-85-20150907.rtp.raleigh.ibm.com', 10039, '/wps/mycontenthandler', 'wpsadmin', 'wpsadmin', 'd:/wcm_design');

var options = {
    includeMeta: false

};
// var host = 'jb-85-20150907.rtp.raleigh.ibm.com', port = 10039, chPath = '/wps/mycontenthandler', secure = false;
var host = 'dxtksp.rtp.raleigh.ibm.com', port = 10041, chPath = '/dxtk/mycontenthandler', secure = true;
wcmHelper.init(host, port, chPath, 'wpsadmin', 'wpsadmin', secure, 'd:/wcm_design').then(function() {
    // wcmHelper.getLibraries().then(function(libs) {
    // console.log('libs ', libs);
    //wcmHelper.pullLibrary('Web Content Templates 3.0').then(function(count) {
    //  console.log('pulled ', count);
     wcmHelper.pushLibrary("Web Content Templates 3.0", true).then(function(pushedList) {
        console.log('pushedList: ', pushedList);
    });
});

/*
wcmHelper.pullLibrary('TestLibrary').then(function(count) {
    console.log('pulled ', count);
        wcmHelper.pushLibrary("TestLibrary", true).then (function (pushedList) {
            console.log('pushedList: ', pushedList);
        } );   
});
wcmHelper.pushLibrary("TestLibrary", true).then(function(pushedList) {
    console.log('pushedList: ', pushedList);
});

*/

/*
wcmRequests.getFolderMap('Web Content Templates 3.0').then(function(map) {
    console.log('folder map: ', map);
});
*/
