# Web Developer Dashboard for IBM Digital Experience

This package provides the dashboard user interface support for the Web Developer Toolkit for IBM Digital Experience. For more information, see the readme.md file for the toolkit.

