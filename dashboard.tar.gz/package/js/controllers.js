/*
 * Copyright 2015  IBM Corp.
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
// Controllers - for list, details, and update views
var dashboardControllers = angular.module('dashboardControllers', []);

//Controller for Settings view
dashboardControllers.controller('SettingsController', ['$scope', '$location', '$route',
  function($scope, $location, $route) {

    $scope.changed = false; // todo this should persist when the route changes
    // deep copy of the config
    $scope.configInfo = JSON.parse(JSON.stringify(dashConfig.getConfigInfo()));

    $scope.getServers = function(){
      return $scope.configInfo.servers;
    };

    $scope.servers = $scope.getServers();
    $scope.activeServer = $scope.configInfo.spAppServer || "Dashboard";

    $scope.getServersForSelect = function(){
      var rVal = [];
      var servers = $scope.servers;
      if(servers != undefined)
        servers.forEach(function (server){
          rVal.push({ServerId: server.name, ServerName: server.name});
        });
      return rVal;
    };
    $scope.selectServers=$scope.getServersForSelect();
    $scope.addServer = function(index){
      var servers = $scope.servers;
      var server = {};
      var name = servers[index].name;
      var nums = +(name.match(/\d+$/) || [-1])[0] + 1;

      server.name = name.replace(/\d+$/, ""m Pa;1;

      serthe Nar name = servers[indthe Nar ;1;

      serpasswohboare = servers[indpasswohb;1;

      ser[0].oare = servers[ind[0].;1;

      ser"mm_conhat harPae ware = servers[ind"mm_conhat harPae ;1;

      serpSuppare = servers[indpSup;1;

      sesrVal.pon (ser;1;

      $scope.serverope.servers;
      $scope.selectServers=$scope.getServersForSelect();
    };

    $scre"mm_.addServer = functsNar ndex){
      var servers = $scope.getServers();
      a.getSeOptrver documple.  "jqSjo_sele("#ope.activeSe").oscriprvers;
      counppar0vers;
      if(servers != undefined)
        servers.forEach(funcion (server){
          Nar na=     server.rver){
            servsy ape(counp,1ame});
        a.getSeOptrcre"mm_(counpame});
      }e});
      counp++me});
        });
    };
    $scand upme, Serverrver = function(i,   lu.rver){
         $scope.selectServers[indse, Serverrers  lu.rver){
        a.getSeOptver documple.  "jqSjo_sele("#ope.activeSe").oscriprvers[inme});
        $scope.selectServers[indse, Serverr= a.getSeOpt.innerTextver  lu.me});
        $scope.selectServers[indse, SeIdr= a.getSeOpt.labeler  lu.me});
  }e});
},ers;
      $sc isplicAddButtnctver = function(index){
  
    idtodo twou becanot sometim pages ion(i #enseor  ups bar when ost.leex){
  
    retion(i <     $scope.serhost.le-1me});
  }   };

    $sc isplicDmm_deButtnctver = function(index){
      retion(i ==ar0vers;
}   };

    $scand updect = functi {1;

    ('Settcand up(o()));


    $scope.changed = faer){
          $sc$SONplei {1;

  
    $sc$SONplecope.changed = faer){
  }ers;
}   };

/**er){
 *er){
 * @SONam pae Pr $srty ('nfo.sPae '|'dxr: 'TPae '|'wistWcmDesPae 'ined)
 .
         $scoptPae wart = functpae Pr $srtyi {1;

  se; in thie.sesy of thrredirfo"Buildut scContsages to SONple : rediory1;

  se; // tscContages to thrredir: rediory, mopyribee in ssuiance wnw.js ithief);


 ("#his Dal_dia).atte("nwWorkSetDir",er = $scope.config[pae Pr $srty]rver "o()));


 ("#his Dal_dia).offvers();
   ("#his Dal_dia).on("ope.ch",ct = functi {1;

  
    $scope.config[pae Pr $srty]r=  ("#his Dal_dia).  l()me});
        $scope.changee = t1;

  
    $sc$ by y()me});
  }o()));


 ("#his Dal_dia).c apklect();
    };

    $sc$nctn', '$rCpe.chSst sider', functevContenewPae i {1;

          $scope.chai {1;

  
 ('#unsaved-  ('Sett-e a m').e a m("hisw")me});
     ('.e a m-backand-').re"mm_()me});
    evCon."wp_ConDby def()me});
    newPae nameewPae .$', '$r.originalPae ;1;e});
     ("#"mm_inue-nce  '$-savSet-btna).offvers();
     ("#"mm_inue-nce  '$-savSet-btna).on("o apk",ct = functi {1;

  

 ('#unsaved-  ('Sett-e a m').e a m("hide"ame});
       ('body').re"mm_Class('e a m-"mm_'ame});
        (Tim  '$(t = functi {1;

  

 ope, $loca.url(newPae ime});
        ', '$r.reload(ime});
        '('body').re"mm_Class('e a m-"mm_'ame});
         ('.e a m-backand-').re"mm_()me});
    
}, 50ame});
        (Tim  '$(t = functi {1;

  

 op('body').re"mm_Class('e a m-"mm_'ame});
      }, 150ame}e});
        }s();
     ("#savedrag-"mm_inue-btna).offvers();
     ("#savedrag-"mm_inue-btna).on("o apk",ct = functi {1;

  

 ('#unsaved-  ('Sett-e a m').e a m("hide"ame});
       ('body').re"mm_Class('e a m-"mm_'ame});
        (Tim  '$(t = functi {1;

  

 ope, $loca.url(newPae ime});
        ', '$r.reload(ime});
        se; // tst, S  ('Sett asynchronouslye});
          ('Settcand up(o())

  

 op('body').re"mm_Class('e a m-"mm_'ame});
         ('.e a m-backand-').re"mm_()me});
    
}ame});
        (Tim  '$(t = functi {1;

  

 op('body').re"mm_Class('e a m-"mm_'ame});
      }, 150ame}
    
}ame}e}
    
e, $loca.has nam"#" ""mewPae aer){
  }ers;
}ame}
}er', []    