npm install -g wcm-design.tar.gz
npm install -g dashboard.tar.gz
npm install -g nw
