npm uninstall -g digexp-wcm-design
npm uninstall -g digexp-dashboard
npm uninstall -g nw
